<?php

session_start();

require_once"connection.php";
$LoginError="";
$role = "";
$errors=0;
$username="";
$password="";
$usernameError="";
$passwordError= "";
if ($_SERVER["REQUEST_METHOD"] == "POST") 
{
    $username = $_POST["username"];
    $password = $_POST["password"];

    if (empty($_POST['username']) && empty($_POST['password']))
    {
        $formError = "Please fill out the required fields";
        $errors=1;
    }
    if (empty($_POST["username"]))
    {
        $usernameError = "Please enter the username";
        $errors= 1;
    }
    if (empty($_POST["password"]))
    {
        $passwordError = "Please enter the password";
        $errors= 1;
    }
    if($errors==0)
    {   
        if(isset($_POST['submit']))
        {
            $query  = "SELECT *FROM Staff where StaffID='$username' AND Password='$password'";
            $result = mysqli_query($conn,$query);
    
            if (mysqli_num_rows($result)>0)
            {
                while($row = mysqli_fetch_assoc($result))
                {
                    if($row["Type"]=="Admin")
                    {
                        $_SESSION['Admin'] = $row["Name"];
                        header("location:admin.php");die();
                    }
                    elseif($row["Type"]=="Doctor")
                    {
                        $_SESSION['Doctor'] = $row["Name"];
                        header("location:doctor.php");die();
                    }
                    else
                    {
                        $_SESSION['Nurse'] = $row["Name"];
                        header("location:nurse.php");die();
                    }
                }
            }
            else
            {
                $LoginError="Incorrect username and/or password";
                //header("location:login.php");
            }
        }
    }
}
?>