
<?php

include "connection.php";
$id=$_GET["id"];
$firstname="";
$lastname="";
$DOB="";
$Address="";
$Telephone="";
$Email="";

$res=mysqli_query($link,"select * from patient where PatientTRN=$id");
while($row=mysqli_fetch_array($res))
{
	
	$firstname=$row["FirstName"];
	$lastname=$row["LastName"];
	$DOB=$row["DOB"]; 
	$Address=$row["Address"];
	$Telephone=$row["TelNo"];
	$Email=$row["Email"];
	
}

?>

<html lang="en">
<head>
  <title>Bootstrap Example</title>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/js/bootstrap.min.js"></script>
</head>

<body>

<div class="container">
<div class="col-lg-4">
  <h2> Nurse Patient Database</h2>
  <form action="" name="form1" method="POST"> 
  
  
   
      
    <div class="form-group">
      <label for="Firstname">firstname:</label>
      <input type="text" class="form-control" id="Firstname" placeholder="Enter Firstname" name="firstname" value= <?php echo $firstname; ?> ">
    </div>
	
    <div class="form-group">
      <label for="Lastname">Lastname:</label>
      <input type="text" class="form-control" id="Lastname" placeholder="Enter password" name="Lastname" value= <?php echo $lastname; ?> ">
    </div>
	
	  <div class="form-group">
      <label for="DOB">DOB:</label>
      <input type="date" class="form-control" id="DOB" placeholder="Enter Date of Birth" name="DOB" value= <?php echo $DOB; ?> ">
	  
    </div>
	
	 <div class="form-group">
      <label for="Address">Address:</label>
      <input type="text" class="form-control" id="address" placeholder="Enter Date of Birth" name="address" value= <?php echo $Address; ?> ">
    </div>
	

	
	
	 <div class="form-group">
      <label for="Telephone">Telephone:</label>
      <input type="text" class="form-control" id="telephones" placeholder="Enter Telephone" name="telephone" value= <?php echo $Telephone; ?> ">
    </div>
	
		 <div class="form-group">
      <label for="Email">Email:</label>
      <input type="text" class="form-control" id="email" placeholder="Enter Date of Birth" name="email" value= <?php echo $Email; ?> ">
    </div>
	
	
    <div class="checkbox">
      <label><input type="checkbox" name="remember"> Remember me</label>
	  
    </div>
    
	<button type="submit" name="Update" class="btn btn-default"> Update</button>

  </form>
</div>
</div>



</div>



</body>


<?php

if(isset($_POST["Update"]))
	
{
mysqli_query($link,"update patient set  firstname='$_POST[firstname]',Lastname='$_POST[Lastname]',DOB='$_POST[DOB]',address='$_POST[address]',telephone='$_POST[telephone]',email='$_POST[email]' where id=$id");
?>

<script type="text/javascript">
window.location="nurse.php";

</script>

<?php
	
}


?>





</html>