<?php
?>
<html lang="en">
   <head>
      <meta charset="utf-8">
      <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
      <meta name="description" content="">
      <meta name="author" content="">
      <title>Avacado Medical Centre-BMI Calculator</title>
      <!-- Bootstrap core CSS -->
      <link href="vendor/bootstrap/css/bootstrap.min.css" rel="stylesheet">
      <!-- Fontawesome CSS -->
      <link href="css/all.css" rel="stylesheet">
      <!-- Custom styles for this template -->
      <link href="css/form1.css" rel="stylesheet">
      <link href="css/style.css" rel="stylesheet">
      <link rel = "icon" href =images/a1.png type = "image/x-icon">
   </head>
   <script type="text/javascript">
      function computeBMI()
      {
          //Obtain user inputs
          var height=Number(document.getElementById("height").value);
          var heightunits=document.getElementById("heightunits").value;
          var weight=Number(document.getElementById("weight").value);
          var weightunits=document.getElementById("weightunits").value;
      
          //Convert all units to metric
          if (heightunits=="inches") height/=39.3700787;
          if (weightunits=="lb") weight/=2.20462;
      
          //Perform calculation
          var BMI=weight/Math.pow(height,2);
      
          //Display result of calculation
          document.getElementById("output").innerText=Math.round(BMI*100)/100;
      
          var output =  Math.round(BMI*100)/100      
          if (output<18.5)
              document.getElementById("comment").innerText = "Underweight";
          else   if (output>=18.5 && output<=25)
              document.getElementById("comment").innerText = "Normal";
          else   if (output>=25 && output<=30)
              document.getElementById("comment").innerText = "Obese";
          else   if (output>30)
              document.getElementById("comment").innerText = "Overweight";
          // document.getElementById("answer").value = output; 
      }
   </script>
   <body>
      <!-- Navigation -->
      <nav class="navbar fixed-top navbar-expand-lg navbar-dark bg-light top-nav fixed-top">
         <div class="container">
            <a class="navbar-brand" href="index.php">
            <img src="images/LOGO1.png" alt="logo" height="60" width="230"/>
            </a>
            <button class="navbar-toggler navbar-toggler-right" type="button" data-toggle="collapse" data-target="#navbarResponsive" aria-controls="navbarResponsive" aria-expanded="false" aria-label="Toggle navigation">
            <span class="fas fa-bars"></span>
            </button>
            <div class="collapse navbar-collapse" id="navbarResponsive">
               <ul class="navbar-nav ml-auto">
                  <li class="nav-item">
                     <a class="nav-link active" href="index.php">Home</a>
                  </li>
                  <li class="nav-item dropdown">
                     <a class="nav-link dropdown-toggle" href="#" id="navbarDropdownPortfolio" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">                 Login
                     </a>
                     <div class="dropdown-menu dropdown-menu-right" aria-labelledby="navbarDropdownPortfolio">
                        <a class="dropdown-item" href="login.php">Login</a>
                        <a class="dropdown-item" href="guest.php">Guest Usert</a>
                     </div>
                  </li>
               </ul>
            </div>
         </div>
      </nav>
      <!-- full Title -->
      <div class="full-title">
         <div class="container">
            <!-- Page Heading/Breadcrumbs -->
            <h1 class="mt-4 mb-3">Add Staff Member
               <small></small>
            </h1>
         </div>
      </div>
      <!-- /.container -->
      <br>
      <div class="login-page">
         <div class="form">
            <div class="login-form" >
               <h1>Body Mass Index Calculator</h1>
               <p>
                  Enter your height: <input type="text" id="height"/>
                  <select type="multiple" id="heightunits">
                     <option value="metres" selected="selected">metres</option>
                     <option value="inches">inches</option>
                  </select>
               </p>
               <p>
                  Enter your weight: <input type="text" id="weight"/>
                  <select type="multiple" id="weightunits">
                     <option value="kg" selected="selected">kilograms</option>
                     <option value="lb">pounds</option>
                  </select>
               </p>
               <button type="submit"onclick="computeBMI();" >Calculate BMI </button>
               <br>
               <h2>Your BMI is: <span id="output"></span></h2>
               <br>
               <h5>This means you are: <span id="comment"></span> </h5>
            </div>
    </div>

      </div>
      <br>
      <!-- Bootstrap core JavaScript -->
      <script src="vendor/jquery/jquery.min.js"></script>
      <script src="vendor/bootstrap/js/bootstrap.bundle.min.js"></script>
      <script src="vendor/bootstrap/js/form.js"></script>
   </body>
</html>