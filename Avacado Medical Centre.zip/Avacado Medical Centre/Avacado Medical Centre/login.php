<?php
   include"login_val.php";
?>
<html>
   <head>
      <link rel="stylesheet" href="log.css">
      <style> 
         .error
         {
         overflow: hidden;
         color : red;
         }        
	  </style>
	      <link rel = "icon" href =images/a1.png type = "image/x-icon"> 

   </head>
   <body>
	<div class="container">
			<div class="log-img">
			<img src="images/clin.png" alt="Profile-pic">	
			</div>
			<div class="login-item">
			<span class="error"><?php echo $LoginError?></span><br>
				<form action="<?= htmlspecialchars($_SERVER["PHP_SELF"]) ?>" method="post" class="form form-login">
				<span class="error"><?php echo $usernameError; ?></span><br><br>
				<div class="form-field">
					<label class="user" for="login-username"><span class="hidden">Username</span></label>
					<input id="login-username" type="text" class="form-input"  name="username" placeholder="User Name" >
				</div>
				<span class="error"><?php echo $passwordError; ?></span><br><br>
				<div class="form-field">
					<label class="lock" for="login-password"><span class="hidden">Password</span></label>
					<input id="login-password" type="password" class="form-input" name="password" placeholder="Password" >
				</div>
				<div class="form-field">
					
					<input type="submit" value="Login" name="submit">
				</div>
				</form>
			</div>
		</div>
   </body>
</html>
<script src="https://use.typekit.net/rjb4unc.js"></script>
<script>try{Typekit.load({ async: true });}catch(e){}</script>