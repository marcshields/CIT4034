<?php
include"connection.php";

session_start();


//Was button clicked to send form as post?
	if(isset($_POST['search']))
	{
//Assign session to variables 
		foreach($_POST as $key=>$value){
			$$key = $value;
			$_SESSION[$key] = $value;
		}
		
		$_SESSION['errFlag'] = 0;


		//fname sql
		$sql = "SELECT PatientTRN, Title, FirstName, LastName, DOB, Address, TelNo, Email FROM Patient WHERE FirstName='".$fName."'";

		//lname sql
		//$sql = "SELECT PatientTRN, Title, FirstName, LastName, Status DOB, Address, TelNo, Email FROM Patient WHERE FirstName='".$lname."'";


		$result = $conn->query($sql);

		if ($result->num_rows > 0) {
		  // output data of each row
		  while($row = $result->fetch_assoc()) {
			echo "PatientTRN: " . $row["PatientTRN"]. 
				 " - Title: " . $row["Title"]. 
				 " - FirstName: " . $row["FirstName"]. 
				 " - LastName: " . $row["LastName"]. 
				 " - DOB: " . $row["DOB"]. 
				 " - Address: " . $row["Address"]. 
				 " - TelNo: " . $row["TelNo"]. 
				 " - Email: " . $row["Email"].
				 "<br>";
		  }
		} else {
		  echo "0 results";
		}

		$conn->close();

	}
?>