<?php
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "acmed_DB";


// Create connection
	$conn = new mysqli($servername, $username, $password, $dbname);
// Check connection
	if ($conn->connect_error) {
	  die("Connection failed: " . $conn->connect_error);
	}
	
//Defaults

$sql = "INSERT INTO Staff (Name, Email, Password, Type)
		VALUES 
		('Admin Gentles', 'agentles@acmed.com', 'Admin', 'Administrator'),
		('Doctor Gentles', 'dgentles@acmed.com', 'Doctor', 'Doctor'),
		('Nurse Gentles', 'ngentles@acmed.com', 'Nurse', 'Nurse');";


$sql = "INSERT INTO Patient (PatientTRN, Title, FirstName, LastName, DOB, Address, TelNo, Email)
		VALUES 
		(123456789, 'Mr', 'User1', 'Test1', '2008-7-04', 'Fareen Me Deh', 12345678, 'user1@email.com'),
		(223456789, 'Ms', 'User2', 'Test2', '2009-7-04', 'Nearby', 12345678, 'user2@email.com'),
		(323456789, 'Mrs', 'User3', 'Test3', '2000-7-04', 'Porus Jamaica', 92345678, 'user3@email.com');";


$sql = "INSERT INTO Appointment (PatientTRN, StaffID, Date)
		VALUES 
		(123456789, 2, '2008-7-04'),
		(223456789, 1, '2020-7-04'),
		(323456789, 2, '2020-7-04');";


		
if ($conn->query($sql) === TRUE) {
  echo "New record created successfully";
} else {
  echo "Error: " . $sql . "<br>" . $conn->error;
}

$conn->close();
?>