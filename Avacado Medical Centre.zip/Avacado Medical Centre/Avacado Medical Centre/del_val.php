<?php
require_once"connection.php";
//Error Counter
$errors= 0;
//Form Variables
$StaffID="";
//Error Variables
$idError       = "";
if ($_SERVER["REQUEST_METHOD"] == "POST") 
{
    if (empty($_POST["StaffID"]))
    {
        $idError = "Staff ID number is required";
        $errors  = 1;
    }
    else
    {
        $StaffID = test_input($_POST["StaffID"]);
        //Checks only if there are numbers, 7 digit long
        if (!preg_match("/^[0-9]{7}$/", $StaffID))
        {
            $idError = "Staff ID number can only contain 7 digits only";
            $errors  = 1;
        }
    }
    if ($errors == 0)
    {
        //3547895
        if(isset($_POST['submit']))
        {
            $StaffID  = $_POST["StaffID"];
            
            $sql = "DELETE FROM staff WHERE StaffID=$StaffID";
            if (mysqli_query($conn, $sql))
            {
               
                header("location:del_suc.php"); 
            } 
            else 
            {
                echo "Error: " . $sql . "" . mysqli_error($conn);
            }
            mysqli_close($conn);
        }
        //
    }
}
function test_input($data)
{
    $data = trim($data);
    $data = stripslashes($data);
    $data = htmlspecialchars($data);
    return $data;
}
?>