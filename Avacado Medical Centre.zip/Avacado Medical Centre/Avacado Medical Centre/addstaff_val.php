<?php
require_once"connection.php";
//Error Counter
$errors= 0;
//Form Variables
$StaffID="";
$Name="";
$Email="";
$Password="";
$Type="";
//Error Variables
$idError       = "";
$nameError     = "";
$emailError    = "";
$typeError     = "";
$formError     = "";
$passwordError = "";
if ($_SERVER["REQUEST_METHOD"] == "POST") 
{
    if (empty($_POST['StaffID']) && empty($_POST['name']) && empty($_POST['email']) && empty($_POST['password']) && empty($_POST['Type']))
    {
        $formError = "Please fill out the required fields";
        $errors=1;
    }
    if (empty($_POST["StaffID"]))
    {
        $idError = "Staff ID number is required";
        $errors  = 1;
    }
    else
    {
        $StaffID = test_input($_POST["StaffID"]);
        //Checks only if there are numbers, 7 digit long
        if (!preg_match("/^[0-9]{7}$/", $StaffID))
        {
            $idError = "Staff ID number can only contain 7 digits only";
            $errors  = 1;
        }
    }
    if (empty($_POST["name"]))
    {
        $nameError = " Please enter the full name";
        $errors= 1;
    }
    else
    {
        $Name = test_input($_POST["name"]);
        // check name only contains letters and whitespace
        if (!preg_match("/^[A-Z][a-zA-Z ]*$/", $Name))
        {
            $nameError = "Name can only contain letters and the first letter must be captial";
            $errors    = 1;
        }
    }
    if (empty($_POST["email"]))
    {
        $emailError = "Email is required";
        $errors     = 1;
    }
    else
    {
        $Email = test_input($_POST["email"]);
        // check if e-mail address syntax is valid or not
        if (!filter_var($Email, FILTER_VALIDATE_EMAIL))
        {
            $emailError = "Invalid email format";
            $errors     = 1;
        }
    }
    if (empty($_POST["password"]))
    {
        $passwordError = "Password is required";
        $errors        = 1;
    }
    if (empty($_POST['Type']))
    {
        $typeError = "Please select the role of the user";
        $errors    = 1;
    }
    if ($errors == 0)
    {
        if(isset($_POST['submit']))
        {
            $StaffID  = $_POST["StaffID"];
            $Name     = $_POST["name"];
            $Password = $_POST["password"];
            $Email    = $_POST["email"];
            $Type     = $_POST["Type"];
            $sql = "INSERT INTO staff (StaffID,Name,Email,Password,Type) values('$StaffID','$Name','$Email','$Password','$Type')";
            if (mysqli_query($conn, $sql))
            {
               // echo "New record created successfully !";
                header("location:success.php"); 
            } 
            else 
            {
                echo "Error: " . $sql . "" . mysqli_error($conn);
            }
            mysqli_close($conn);
        }
        //
    }
}
function test_input($data)
{
    $data = trim($data);
    $data = stripslashes($data);
    $data = htmlspecialchars($data);
    return $data;
}
?>