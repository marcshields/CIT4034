<?php
	


	if(isset($_POST['save']))
	{
		//Assign session to variables 
		foreach($_POST as $key=>$value){
			$$key = $value;
			$_SESSION[$key] = $value;
		}
		
		$_SESSION['errFlag'] = 0;
		
		
	}
















?>
