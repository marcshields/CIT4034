<?php
session_start();

if(isset($_POST['Display'])){
	header("Location:display.php");
	
}


?>