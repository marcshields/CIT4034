<?php
session_start();
?>
<?php include"patient_comm.php";?>
<html lang="en">
   <head>
      <meta charset="utf-8">
      <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
      <meta name="description" content="">
      <meta name="author" content="">
      <title>Avacado Medical Centre-Admin Page</title>
      <!-- Bootstrap core CSS -->
      <link href="vendor/bootstrap/css/bootstrap.min.css" rel="stylesheet">
      <!-- Fontawesome CSS -->
      <link href="css/all.css" rel="stylesheet">
      <!-- Custom styles for this template -->
      <link href="css/form1.css" rel="stylesheet">
      <link href="css/style.css" rel="stylesheet">
      <link rel = "icon" href =images/a1.png type = "image/x-icon">
      <style>
            .error{
                color:red;
            }
        </style>
   </head>
   <body>
      <!-- Navigation -->
      <nav class="navbar fixed-top navbar-expand-lg navbar-dark bg-light top-nav fixed-top">
         <div class="container">
            <a class="navbar-brand" href="index.php">
            <img src="images/LOGO1.png" alt="logo" height="60" width="230"/>
            </a>
            <button class="navbar-toggler navbar-toggler-right" type="button" data-toggle="collapse" data-target="#navbarResponsive" aria-controls="navbarResponsive" aria-expanded="false" aria-label="Toggle navigation">
            <span class="fas fa-bars"></span>
            </button>
            <div class="collapse navbar-collapse" id="navbarResponsive">
               <ul class="navbar-nav ml-auto">
                  <li class="nav-item">
                     <a class="nav-link active" href="index.php">Home</a>
                  </li>
                  <li class="nav-item dropdown">
                     <a class="nav-link dropdown-toggle" href="#" id="navbarDropdownPortfolio" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">                 Login
                     </a>
                     <div class="dropdown-menu dropdown-menu-right" aria-labelledby="navbarDropdownPortfolio">
                        <a class="dropdown-item" href="login.php">Login</a>
                        <a class="dropdown-item" href="logout.php">Log Out</a>
                     </div>
                  </li>
               </ul>
            </div>
         </div>
      </nav>
      <!-- full Title -->
	
      <div class="full-title">
         <div class="container">
            <!-- Page Heading/Breadcrumbs -->
            <h1 class="mt-4 mb-3">Log Patient
               <small></small>
            </h1>
         </div>
      </div>
      <!-- /.container -->
      <br>
      <div class="login-page">
  <div class="form">
	<form method="post" class="login-form" action="patient_comm.php">
    <span class="error" display:none;></span><br>
        Patient TRN<br>
        <span class="error"></span><br>
		<input style=""type="text" name="StaffID" value=""  placeholder="123456798">
        <br><br>


        Title<br>
		<span class="error"></span><br>
	    <select class="custom-select" required>
		<option value="">Title</option>
		<option value="Mr">Mr</option>
		<option value="Ms">Ms</option>
		<option value="Mrs">Mrs</option>
		</select>
        <br><br>
 

		First Name<br>
        <span class="error"></span><br>
		<input type="text" name="fName"value=""  placeholder="JOHN">
        <br><br>
        Last Name:<br>
        <span class="error"></span><br>
		<input type="text" name="lName" value="" placeholder="DOE">
        <br><br>
		
        Date Of Birth<br>
        <span class="error" ></span><br>
		<input type="Date" name="dob" value="">
        <br><br>
		
		Address<br>
        <span class="error"></span><br>
		<input type="text" name="address"value=""  placeholder="Kingston, Jamaica">
        <br><br>
      
		Tel#<br>
        <span class="error"></span><br>
		<input style="" type="tel" name="tel" value=""  placeholder="876-1235679">
        <br><br>	
 		
		Email<br>
        <span class="error"></span><br>
		<input type="email" name="email" value=""  placeholder="email@email.com">
        <br><br>

       <button type="submit" name="save">SAVE</button>

		
    </form>
</div>




      <!-- Bootstrap core JavaScript -->
      <script src="vendor/jquery/jquery.min.js"></script>
      <script src="vendor/bootstrap/js/bootstrap.bundle.min.js"></script>
      <script src="vendor/bootstrap/js/form.js"></script>
   </body>
</html>