<?php

include "connection.php";


?>

<html lang="en">
<head>
  <title>Bootstrap Example</title>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/js/bootstrap.min.js"></script>
</head>

<body>

<div class="col-lg-12">
<table class="table table-bordered">
    <thead>
      <tr>
	   <th>TRN</th>
		 <th>Title</th>
        <th>Firstname</th>
        <th>Lastname</th>
		 <th>DOB</th>
		  <th>Address</th>
		   <th>Telephone</th>
        <th>Email</th>
      </tr>
    </thead>
    <tbody>
	
	<?php
	
	
	$res=mysqli_query($link,"select * from patient");
	while($row=mysqli_fetch_array($res))
	{
		echo "<tr>";
		
		echo "<td>"; echo $row["PatientTRN"]; echo"</td>";
		echo "<td>"; echo $row["Title"]; echo"</td>";
		echo "<td>"; echo $row["FirstName"]; echo"</td>";
		echo "<td>"; echo $row["LastName"]; echo"</td>";
		echo "<td>"; echo $row["DOB"]; echo"</td>";
		echo "<td>"; echo $row["Address"]; echo"</td>";
		echo "<td>"; echo $row["TelNo"]; echo"</td>";
		echo "<td>"; echo $row["Email"]; echo"</td>";
		
		echo "</tr>";
		
		
	}
	

	?>
	
	
   
      
    </tbody>
  </table>

</div>



</body>
</html>











