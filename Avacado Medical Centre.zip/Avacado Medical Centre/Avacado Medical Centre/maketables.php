<?php
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "acmed_DB";


// Create connection
	$conn = new mysqli($servername, $username, $password, $dbname);
// Check connection
	if ($conn->connect_error) {
	  die("Connection failed: " . $conn->connect_error);
	}

// sql to create tables

$sql = "CREATE TABLE Staff (
	StaffID INT(6) AUTO_INCREMENT PRIMARY KEY,
	Name VARCHAR(60) NOT NULL,
	Email VARCHAR(50) NOT NULL,
	Password VARCHAR(50) NOT NULL,
	Type VARCHAR(15) NOT NULL,
	check(Type in ('Nurse', 'Doctor', 'Administrator'))
	)";

$sql = "CREATE TABLE Patient (
	PatientTRN INT(15) PRIMARY KEY,
	Title VARCHAR(5) NOT NULL,
	FirstName VARCHAR(50) NOT NULL,
	LastName VARCHAR(50) NOT NULL,
	DOB DATE NOT NULL,
	Address VARCHAR(50) NOT NULL,
	TelNo INT(15) NOT NULL,
	Email VARCHAR(50) NOT NULL,
	check(Title in ('Mr', 'Ms', 'Mrs'))
	)";



$sql = "CREATE TABLE Appointment (
	PatientTRN INT(15) NOT NULL,
	StaffID INT(6) NOT NULL,
	Date DATE NOT NULL,
	ReasonForVisit VARCHAR(100),
	Status VARCHAR(10) DEFAULT 'pending',
	CONSTRAINT FK_PatientTRN FOREIGN KEY (PatientTRN) REFERENCES Patient (PatientTRN),
	CONSTRAINT FK_StaffID FOREIGN KEY (StaffID) REFERENCES Staff (StaffID),	
	check(Status in ('pending', 'cancelled', 'complete'))
	)";


if ($conn->query($sql) === TRUE) {
  echo "Tables created successfully";
} else {
  echo "Error creating tables: " . $conn->error;
}

$conn->close();
?>