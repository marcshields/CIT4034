<?php

$dbname = "acmed_db";
$dbhost ="localhost";
$dbpass = "";
$dbuser = "root";
$conn = mysqli_connect($dbhost,$dbuser,$dbpass,$dbname); 

if(!$conn)
{
     echo"Connection  not Succesful";
}
?>