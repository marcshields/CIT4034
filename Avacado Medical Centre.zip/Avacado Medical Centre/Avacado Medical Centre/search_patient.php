<?php
include"connection.php";

session_start();

		if(empty($_SESSION['fName']))
	{
		$fName="";
	}
	else{
		$fName=$_SESSION['fName'];
	}
	
	if(isset($_POST['search']))
	{	
			$sql = "SELECT * FROM patient WHERE ".$_POST['nameType']." = '".$_POST['fName']."';";					  
			$result = $conn->query($sql);		
	}
	else{
		$sql = "";
		$result = "";
		}
	
	?>
	
	
<html lang="en">
   <head>
      <meta charset="utf-8">
      <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
      <meta name="description" content="">
      <meta name="author" content="">
      <title>Avacado Medical Centre-Admin Page</title>
      <!-- Bootstrap core CSS -->
      <link href="vendor/bootstrap/css/bootstrap.min.css" rel="stylesheet">
      <!-- Fontawesome CSS -->
      <link href="css/all.css" rel="stylesheet">
      <!-- Custom styles for this template -->
      <link href="css/form1.css" rel="stylesheet">
      <link href="css/style.css" rel="stylesheet">
      <link rel = "icon" href =images/a1.png type = "image/x-icon">
      <style>
            .error{
                color:red;
            }
        </style>
   </head>
   <body>
      <!-- Navigation -->
      <nav class="navbar fixed-top navbar-expand-lg navbar-dark bg-light top-nav fixed-top">
         <div class="container">
            <a class="navbar-brand" href="index.php">
            <img src="images/LOGO1.png" alt="logo" height="60" width="230"/>
            </a>
            <button class="navbar-toggler navbar-toggler-right" type="button" data-toggle="collapse" data-target="#navbarResponsive" aria-controls="navbarResponsive" aria-expanded="false" aria-label="Toggle navigation">
            <span class="fas fa-bars"></span>
            </button>
            <div class="collapse navbar-collapse" id="navbarResponsive">
               <ul class="navbar-nav ml-auto">
                  <li class="nav-item">
                     <a class="nav-link active" href="index.php">Home</a>
                  </li>
                  <li class="nav-item dropdown">
                     <a class="nav-link dropdown-toggle" href="#" id="navbarDropdownPortfolio" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">                 Login
                     </a>
                     <div class="dropdown-menu dropdown-menu-right" aria-labelledby="navbarDropdownPortfolio">
                        <a class="dropdown-item" href="login.php">Login</a>
                        <a class="dropdown-item" href="logout.php">Log Out</a>
                     </div>
                  </li>
               </ul>
            </div>
         </div>
      </nav>
      <!-- full Title -->
	
      <div class="full-title">
         <div class="container">
            <!-- Page Heading/Breadcrumbs -->
            <h1 class="mt-4 mb-3">SEARCH PATIENT
               <small></small>
            </h1>
         </div>
      </div>
      <!-- /.container -->
      <br>


     <div class="login-page">
  <div class="form">
	<form method="post" class="login-form" action="search_patient.php">
    <span class="error" display:none;></span><br>
        <br>
		<span class="error"></span><br>
	    <select class="custom-select" name="nameType" required>
			<option value="">NAME TYPE</option>
			<option value="FirstName">First Name</option>
			<option value="LastName">Last Name</option>

		</select>
        <br><br>
		
		
        <span class="error"></span><br>
		<input type="text" name="fName" value="<?php echo$fName?>"  placeholder="JOHN" required>
        <br><br>

       <button type="submit" name="search">SEARCH</button>
		
		<table class="table">
  <thead>
    <tr>
       <th scope="col">TRN</th>
	   <th scope="col">Title</th>
      <th scope="col">First</th>
      <th scope="col">Last</th>
      <th scope="col">DOB</th>
      <th scope="col">Address</th>
      <th scope="col">TelNo.</th>
      <th scope="col">Email</th>
    </tr>
  </thead>
  <tbody>
    
      <?php

	  
	  if($result){  		
		
		if ($result->num_rows > 0) {
	  
	  while($row = $result->fetch_assoc()){ ?>
	<tr>
	  <td> <?php echo $row["PatientTRN"]?></td>
	  <td> <?php echo $row["Title"]?></td>
	  <td> <?php echo $row["FirstName"]?></td>
	  <td> <?php echo $row["LastName"]?></td>
	  <td> <?php echo $row["DOB"]?></td>
	  <td> <?php echo $row["Address"]?></td>
	  <td> <?php echo $row["TelNo"]?></td>
	  <td> <?php echo $row["Email"] ?></td>
	  <?php  } 
	
	}else {
		  echo "<td> 0 results</td>";
		}
	  }else{
  echo "";
}
		?>
    </tr>

	  </tbody>
	</table>
		
    </form>
</div>


      <!--footer starts from here-->
      <footer class="footer">
         <div class="container bottom_border">
         <div class="container">
            <div class="footer-logo">
               <a href="index.php"><img src="images/a1.png" height="60" width= "60" alt="" /></a>
            </div>
            <!--foote_bottom_ul_amrc ends here-->
            <ul class="social_footer_ul">
               <li><a href="#"><i class="fab fa-facebook-f"></i></a></li>
               <li><a href="#"><i class="fab fa-twitter"></i></a></li>
               <li><a href="#"><i class="fab fa-linkedin"></i></a></li>
               <li><a href="#"><i class="fab fa-instagram"></i></a></li>
            </ul>
            <!--social_footer_ul ends here-->
         </div>
      </footer>
      <!-- Bootstrap core JavaScript -->
      <script src="vendor/jquery/jquery.min.js"></script>
      <script src="vendor/bootstrap/js/bootstrap.bundle.min.js"></script>
      <script src="vendor/bootstrap/js/form.js"></script>
   </body>
</html>