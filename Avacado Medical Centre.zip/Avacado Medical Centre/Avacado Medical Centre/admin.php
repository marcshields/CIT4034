<?php
	session_start();
	if(!isset($_SESSION['Admin']))
	{
		header("location:login.php"); die();
	}
	
?>
<html lang="en">
   <head>
      <meta charset="utf-8">
      <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
      <meta name="description" content="">
      <meta name="author" content="">
      <title>Avacado Medical Centre-Admin Page</title>
      <!-- Bootstrap core CSS -->
      <link href="vendor/bootstrap/css/bootstrap.min.css" rel="stylesheet">
      <!-- Fontawesome CSS -->
      <link href="css/all.css" rel="stylesheet">
      <!-- Custom styles for this template -->
      <link href="css/form.css" rel="stylesheet">
      <link href="css/style.css" rel="stylesheet">
      <link rel = "icon" href =images/a1.png type = "image/x-icon">
      <style> 
      </style>
   </head>
   <body>
      <!-- Navigation -->
      <nav class="navbar fixed-top navbar-expand-lg navbar-dark bg-light top-nav fixed-top">
         <div class="container">
            <a class="navbar-brand" href="index.php">
            <img src="images/LOGO1.png" alt="logo" height="60" width="230"/>
            </a>
            <button class="navbar-toggler navbar-toggler-right" type="button" data-toggle="collapse" data-target="#navbarResponsive" aria-controls="navbarResponsive" aria-expanded="false" aria-label="Toggle navigation">
            <span class="fas fa-bars"></span>
            </button>
            <div class="collapse navbar-collapse" id="navbarResponsive">
               <ul class="navbar-nav ml-auto">
                  <li class="nav-item">
                     <a class="nav-link active" href="index.php">Home</a>
                  </li>
                  <li class="nav-item dropdown">
                     <a class="nav-link dropdown-toggle" href="#" id="navbarDropdownPortfolio" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">                 Login
                     </a>
                     <div class="dropdown-menu dropdown-menu-right" aria-labelledby="navbarDropdownPortfolio">
                        <a class="dropdown-item" href="login.php">Login</a>
                        <a class="dropdown-item" href="logout.php">Log Out</a>
                     </div>
                  </li>
               </ul>
            </div>
         </div>
      </nav>
      <!-- full Title -->
      <div class="full-title">
         <div class="container">
            <!-- Page Heading/Breadcrumbs -->
            <h1 class="mt-4 mb-3">Welcome <?php echo $_SESSION['Admin'];?> 
               <small></small>
            </h1>
         </div>
      </div>
      <!-- /.container -->
      <br>
      
      <center> 
      <div class="error-contents">
         <a class="btn btn-primary" href="add_staff.php">Add Staff</a>
         <a class="btn btn-primary" href="update_form.php">Update Staff</a>
         <a class="btn btn-primary" href="del_staff.php">Remove Staff</a>

      </div>
      </center>
      <br>
      <!--footer starts from here-->
      <footer class="footer">
         <div class="container bottom_border">
         <div class="container">
            <div class="footer-logo">
               <a href="index.php"><img src="images/a1.png" height="60" width= "60" alt="" /></a>
            </div>
            <!--foote_bottom_ul_amrc ends here-->
            <ul class="social_footer_ul">
               <li><a href="#"><i class="fab fa-facebook-f"></i></a></li>
               <li><a href="#"><i class="fab fa-twitter"></i></a></li>
               <li><a href="#"><i class="fab fa-linkedin"></i></a></li>
               <li><a href="#"><i class="fab fa-instagram"></i></a></li>
            </ul>
            <!--social_footer_ul ends here-->
         </div>
      </footer>
      <!-- Bootstrap core JavaScript -->
      <script src="vendor/jquery/jquery.min.js"></script>
      <script src="vendor/bootstrap/js/bootstrap.bundle.min.js"></script>
      <script src="vendor/bootstrap/js/form.js"></script>
   </body>
</html>