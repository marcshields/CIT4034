




<?php

include "connection1.php";


?>

<html lang="en">
   <head>
      <meta charset="utf-8">
      <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
      <meta name="description" content="">
      <meta name="author" content="">
      <title>Avacado Medical Centre-Admin Page</title>
      <!-- Bootstrap core CSS -->
      <link href="vendor/bootstrap/css/bootstrap.min.css" rel="stylesheet">
      <!-- Fontawesome CSS -->
      <link href="css/all.css" rel="stylesheet">
      <!-- Custom styles for this template -->
      <link href="css/form1.css" rel="stylesheet">
      <link href="css/style.css" rel="stylesheet">
      <link rel = "icon" href =images/a1.png type = "image/x-icon">
      <style>
            .error{
                color:red;
            }
        </style>
   </head>
   <body>
      <!-- Navigation -->
      <nav class="navbar fixed-top navbar-expand-lg navbar-dark bg-light top-nav fixed-top">
         <div class="container">
            <a class="navbar-brand" href="index.php">
            <img src="images/LOGO1.png" alt="logo" height="60" width="230"/>
            </a>
            <button class="navbar-toggler navbar-toggler-right" type="button" data-toggle="collapse" data-target="#navbarResponsive" aria-controls="navbarResponsive" aria-expanded="false" aria-label="Toggle navigation">
            <span class="fas fa-bars"></span>
            </button>
            <div class="collapse navbar-collapse" id="navbarResponsive">
               <ul class="navbar-nav ml-auto">
                  <li class="nav-item">
                     <a class="nav-link active" href="index.php">Home</a>
                  </li>
                  <li class="nav-item dropdown">
                     <a class="nav-link dropdown-toggle" href="#" id="navbarDropdownPortfolio" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">                 Login
                     </a>
                     <div class="dropdown-menu dropdown-menu-right" aria-labelledby="navbarDropdownPortfolio">
                        <a class="dropdown-item" href="login.php">Login</a>
                        <a class="dropdown-item" href="logout.php">Log Out</a>
                     </div>
                  </li>
               </ul>
            </div>
         </div>
      </nav>
      <!-- full Title -->
      <div class="full-title">
         <div class="container">
            <!-- Page Heading/Breadcrumbs -->
            <h1 class="mt-4 mb-3"> Make Your Appointment
               <small></small>
            </h1>
         </div>
      </div>
      <!-- /.container -->
      <br>
      <div class="login-page">
  <div class="form">
	<form method="post" class="login-form" action="<?= htmlspecialchars($_SERVER["PHP_SELF"]) ?>">
     <form action="nurse.php" name="form1" method="POST"> 
  
  <div class="form-group">
  
  <div class="form-group">
      <label for="title">staffid:</label>
      <input type="text" class="form-control" id="title" placeholder="Name" name="StaffID">
    </div>
      
  
   
		 <div class="form-group">
      <label for="Email">date:</label>
      <input type="date" class="form-control" id="email" placeholder="Enter Date of Birth" name="date">
    </div>
	
	
	
	  <div class="form-group">
      <label for="title">status:</label>
      <input type="text" class="form-control" id="title" placeholder="Name" name="status">
    </div>
	
    <div class="checkbox">
      <label><input type="checkbox" name="remember"> Remember me</label>
	  
    </div>
    <button type="submit" name="insert" class="btn btn-default"> Insert</button>

  </form>
</div>
</div>


<div class="col-lg-12">
<table class="table table-bordered">
    <thead>
      <tr>
	   <th>TRN</th>
		 <th>Staff ID</th>
        <th>Reason For Visit</th>
        <th>Status/th>
		
		
		<th>Edit</th>
		<th>Delete</th>
	
		
      </tr>
    </thead>
    <tbody>
	
	<?php
	$res=mysqli_query($link,"select * from appointment");
	while($row=mysqli_fetch_array($res))
	{
		echo "<tr>";
		
		echo "<td>"; echo $row["PatientTRN"]; echo"</td>";
		echo "<td>"; echo $row["StaffID"]; echo"</td>";
		echo "<td>"; echo $row["ReasonForVisit"]; echo"</td>";
		echo "<td>"; echo $row["Status"]; echo"</td>";
	
		
		echo "<td>"; ?> <a href="edit.php?id=<?php echo $row["PatientTRN"];  ?>"> <button type="button" class="btn btn-success"> Edit</button> </a> <?php echo "</td>";
		echo "<td>"; ?> <a href="delete.php?id=<?php echo $row["PatientTRN"];  ?>"> <button type="button" class="btn btn-danger"> Delete</button> </a> <?php echo "</td>";
		
		echo "</tr>";
		
		
	}
	
	
	?>
	
	
   
      
    </tbody>
  </table>

</div>



</body>
</html>

 <!-- Bootstrap core JavaScript -->
      <script src="vendor/jquery/jquery.min.js"></script>
      <script src="vendor/bootstrap/js/bootstrap.bundle.min.js"></script>
      <script src="vendor/bootstrap/js/form.js"></script>

<?php
if(isset($_POST["insert"])){
	
	mysqli_query($link,"insert into appointment values(NULL,'$_POST[StaffID]','$_POST[date]','','$_POST[status]')");
	
	?>
	
	<script type="text/javascript">
	window.location.href=window.location.href;
	</script>
	<?php
} 

     
 
