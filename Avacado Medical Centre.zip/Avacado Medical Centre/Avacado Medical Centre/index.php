<html lang="en">
<head>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
	<meta name="description" content="">
	<meta name="author" content="">
	<title>Avacado Medical Centre </title>
	<!-- Bootstrap core CSS -->
	<link href="vendor/bootstrap/css/bootstrap.min.css" rel="stylesheet">
	<!-- Fontawesome CSS -->
	<link href="css/all.css" rel="stylesheet">
	<!-- Custom styles for this template -->
    <link href="css/style.css" rel="stylesheet">
    
    <link rel = "icon" href =images/a1.png type = "image/x-icon"> 
</head>
<body>
    <!-- Navigation -->
    <nav class="navbar fixed-top navbar-expand-lg navbar-dark bg-light top-nav fixed-top">
        <div class="container">
            <a class="navbar-brand" href="index.php">
            <img src="images/LOGO1.png" alt="logo" height="60" width="230"/>
            </a>
            <button class="navbar-toggler navbar-toggler-right" type="button" data-toggle="collapse" data-target="#navbarResponsive" aria-controls="navbarResponsive" aria-expanded="false" aria-label="Toggle navigation">
				<span class="fas fa-bars"></span>
            </button>
            <div class="collapse navbar-collapse" id="navbarResponsive">
               <ul class="navbar-nav ml-auto">
                  <li class="nav-item">
                     <a class="nav-link active" href="index.html">Home</a>
                  </li>
                  <li class="nav-item dropdown">
                     <a class="nav-link dropdown-toggle" href="#" id="navbarDropdownPortfolio" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                     Login
                     </a>
                     <div class="dropdown-menu dropdown-menu-right" aria-labelledby="navbarDropdownPortfolio">
                        <a class="dropdown-item" href="login.php"> Staff Only Login</a>
                        <a class="dropdown-item" href="guest.php">Guest User Login</a>
						
						
                     </div>
                  </li>
               </ul>
            </div>
        </div>
    </nav>
    <header class="slider-main">
        <div id="carouselExampleIndicators" class="carousel slide carousel-fade" data-ride="carousel">
            <ol class="carousel-indicators">
               <li data-target="#carouselExampleIndicators" data-slide-to="0" class="active"></li>
               <li data-target="#carouselExampleIndicators" data-slide-to="1"></li>
               <li data-target="#carouselExampleIndicators" data-slide-to="2"></li>
            </ol>
            <div class="carousel-inner" role="listbox">
               <!-- Slide One - Set the background image for this slide in the line below -->
               <div class="carousel-item active" style="background-image: url('images/slider1.png')">
                  <div class="carousel-caption d-none d-md-block">
                     <h3>Welcome to Avacado Medical Centre</h3>
                     <p>A great centre for healthy lifestyle</p>
                  </div>
               </div>
               <!-- Slide Two - Set the background image for this slide in the line below -->
               <div class="carousel-item" style="background-image: url('images/slider2.jpg')">
                  <div class="carousel-caption d-none d-md-block">
                     <h3>Top Doctors</h3>
                     <p>Best of the best</p>
                  </div>
               </div>
               <!-- Slide Three - Set the background image for this slide in the line below -->
               <div class="carousel-item" style="background-image: url('images/slider1.jfif')">
                  <div class="carousel-caption d-none d-md-block">
                     <h3>We Care</h3>
                     <p>Take care of your healthy today</p>
                  </div>
               </div>
            </div>
            <a class="carousel-control-prev" href="#carouselExampleIndicators" role="button" data-slide="prev">
				<span class="carousel-control-prev-icon" aria-hidden="true"></span>
				<span class="sr-only">Previous</span>
            </a>
            <a class="carousel-control-next" href="#carouselExampleIndicators" role="button" data-slide="next">
				<span class="carousel-control-next-icon" aria-hidden="true"></span>
				<span class="sr-only">Next</span>
            </a>
        </div>
    </header>
    <!-- Page Content -->
    <div class="container">
        <div class="services-bar">
            <h1 class="my-4">Our Top Doctors </h1>
            <!-- Services Section -->
            <div class="row">
               <div class="col-lg-4 mb-4">
                  <div class="card h-100">
                     <h4 class="card-header">Mae Jemison</h4>
                     <div class="card-img">
                        <img class="img-fluid" src="images/doc1.jpg" alt="" />
                     </div>
                     <div class="card-body">
                        <p class="card-text">It is health that is real wealth and not pieces of gold and silver.</p>
                     </div>
                  </div>
               </div>
               <div class="col-lg-4 mb-4">
                  <div class="card h-100">
                     <h4 class="card-header">Rochelle Wilson</h4>
                     <div class="card-img">
                        <img class="img-fluid" src="images/doc2.jpg" alt="" />
                     </div>
                     <div class="card-body">
                        <p class="card-text">He who has health has hope; and he who has hope has everything.</p>
                     </div>
                  </div>
               </div>
               <div class="col-lg-4 mb-4">
                  <div class="card h-100">
                     <h4 class="card-header">Monique Thomas</h4>
                     <div class="card-img">
                        <img class="img-fluid" src="images/doc3.jpg" alt="" />
                     </div>
                     <div class="card-body">
                        <p class="card-text">Keep your vitality. A life without health is like a river without water.</p>
                     </div>
                  </div>
               </div>
            </div>
            <!-- /.row -->
        </div>
        <!-- About Section -->
        <div class="about-main">
            <div class="row">
               <div class="col-lg-6">
                  <h2>Avacado Medical Centre</h2>
                  <p>The Committee of Higher Education in the Colonies in 1945 recommended the establishment of a Avacado Medical Centre and Jamaica was chosen as the site. It was decided that the first faculty should be that of medicine as there was a shortage of medical personnel in the region.</p>
                  <h5>Our smart approach</h5>
                  <ul>
                     <li>Achieve/Maintain a healthy weight.</li>
                     <li>Spend quality time with family or friends daily</li>
                     <li>Take time daily for spiritual renewal</li>
                     <li>Choose healthy fats.</li>
                     <li>Get regular physical activity</li>
                  </ul>
                  <p>Taking time for daily relaxation and recreation is also helpful to the body and mind</p>
               </div>
               <div class="col-lg-6">
                  <img class="img-fluid rounded" src="images/about-img.jpg" alt="" />
               </div>
            </div>
            <!-- /.row -->
        </div>
     </div>
    <!-- /.container -->
    <!--footer starts from here-->
    <footer class="footer">
        <div class="container bottom_border">
        <div class="container">
            <div class="footer-logo">
				<a href="index.php"><img src="images/a1.png" height="60" width= "60" alt="" /></a>
			</div>
            <!--foote_bottom_ul_amrc ends here-->
            </p>
            <ul class="social_footer_ul">
				<li><a href="#"><i class="fab fa-facebook-f"></i></a></li>
				<li><a href="#"><i class="fab fa-twitter"></i></a></li>
				<li><a href="#"><i class="fab fa-linkedin"></i></a></li>
				<li><a href="#"><i class="fab fa-instagram"></i></a></li>
            </ul>
            <!--social_footer_ul ends here-->
        </div>
    </footer>
	  
<!-- Bootstrap core JavaScript -->
<script src="vendor/jquery/jquery.min.js"></script>
<script src="vendor/bootstrap/js/bootstrap.bundle.min.js"></script>
</body>
</html>