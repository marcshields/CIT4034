<?php
include "connection.php";
$id= $_GET["id"];
mysqli_query($link,"delete from patient where PatientTRN=$id");



?>
<script type="text/javascript">
window.location="nurse.php";

</script>