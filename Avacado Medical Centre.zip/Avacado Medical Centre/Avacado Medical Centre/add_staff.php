<?php
session_start();
?>
<?php include"addstaff_val.php";?>
<html lang="en">
   <head>
      <meta charset="utf-8">
      <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
      <meta name="description" content="">
      <meta name="author" content="">
      <title>Avacado Medical Centre-Admin Page</title>
      <!-- Bootstrap core CSS -->
      <link href="vendor/bootstrap/css/bootstrap.min.css" rel="stylesheet">
      <!-- Fontawesome CSS -->
      <link href="css/all.css" rel="stylesheet">
      <!-- Custom styles for this template -->
      <link href="css/form1.css" rel="stylesheet">
      <link href="css/style.css" rel="stylesheet">
      <link rel = "icon" href =images/a1.png type = "image/x-icon">
      <style>
            .error{
                color:red;
            }
        </style>
   </head>
   <body>
      <!-- Navigation -->
      <nav class="navbar fixed-top navbar-expand-lg navbar-dark bg-light top-nav fixed-top">
         <div class="container">
            <a class="navbar-brand" href="index.php">
            <img src="images/LOGO1.png" alt="logo" height="60" width="230"/>
            </a>
            <button class="navbar-toggler navbar-toggler-right" type="button" data-toggle="collapse" data-target="#navbarResponsive" aria-controls="navbarResponsive" aria-expanded="false" aria-label="Toggle navigation">
            <span class="fas fa-bars"></span>
            </button>
            <div class="collapse navbar-collapse" id="navbarResponsive">
               <ul class="navbar-nav ml-auto">
                  <li class="nav-item">
                     <a class="nav-link active" href="index.php">Home</a>
                  </li>
                  <li class="nav-item dropdown">
                     <a class="nav-link dropdown-toggle" href="#" id="navbarDropdownPortfolio" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">                 Login
                     </a>
                     <div class="dropdown-menu dropdown-menu-right" aria-labelledby="navbarDropdownPortfolio">
                        <a class="dropdown-item" href="login.php">Login</a>
                        <a class="dropdown-item" href="logout.php">Log Out</a>
                     </div>
                  </li>
               </ul>
            </div>
         </div>
      </nav>
      <!-- full Title -->
      <div class="full-title">
         <div class="container">
            <!-- Page Heading/Breadcrumbs -->
            <h1 class="mt-4 mb-3">Add Staff Member
               <small></small>
            </h1>
         </div>
      </div>
      <!-- /.container -->
      <br>
      <div class="login-page">
  <div class="form">
	<form method="post" class="login-form" action="<?= htmlspecialchars($_SERVER["PHP_SELF"]) ?>">
    <span class="error" display:none;><?php echo $formError; ?></span><br>
        StaffId<br>
        <span class="error"><?php echo $idError; ?></span><br>
		<input style=""type="text" name="StaffID" value="<?php echo $StaffID; ?>">
        <br><br>
        Name<br>
        <span class="error"><?php echo $nameError; ?></span><br>
		<input type="text" name="name"value="<?php echo $Name; ?>">
        <br><br>
        Password:<br>
        <span class="error"><?php echo $passwordError; ?></span><br>
		<input type="password" name="password" value="<?php echo $Password; ?>">
        <br>
        <br>
        Email Id:<br>
        <span class="error" display:none;><?php echo $emailError; ?></span><br>
		<input type="text" name="email" value="<?php echo $Email; ?>">
        <br><br>
        <div id="radioGroup">
            
            <label>Role</label>
            <span class="error"><?php echo $typeError; ?></span><br>

            <label class="label" for="Doctor">Admin</label>         
            <input id="Type" type="radio" name="Type" value="Admin" <?php if(isset($_POST['Type']) && $_POST['Type'] =='Admin' ){echo "checked";}?>>

            <label for="Doctor">Doctor</label>
            <input id="Type" type="radio" name="Type" value="Doctor" <?php if(isset($_POST['Type']) && $_POST['Type'] =='Doctor' ){echo "checked";}?>>

            <label for="Nurse">Nurse</label>
            <input id="Type" type="radio" name="Type" value="Nurse" <?php if(isset($_POST['Type']) && $_POST['Type'] =='Nurse' ){echo "checked";}?> >

            <br>
            <br>
        </div>
        <button type="submit" name="submit">Add Staff</button>
    </form>
</div>

      <br>

      <!-- Bootstrap core JavaScript -->
      <script src="vendor/jquery/jquery.min.js"></script>
      <script src="vendor/bootstrap/js/bootstrap.bundle.min.js"></script>
      <script src="vendor/bootstrap/js/form.js"></script>
   </body>
</html>